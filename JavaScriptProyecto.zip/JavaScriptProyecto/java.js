// 1. Inicializar base de datos ficticia en localStorage si está vacía
if (!localStorage.getItem('sm_products')) {
    const dummyProducts = [{
            id: 101,
            name: "Teclado Mecánico",
            category: "Periféricos",
            price: 45.00,
            stock: 15
        },
        {
            id: 102,
            name: "Monitor 24 pulgadas",
            category: "Pantallas",
            price: 120.00,
            stock: 8
        }
    ];
    localStorage.setItem('sm_products', JSON.stringify(dummyProducts));
}
if (!localStorage.getItem('sm_sales_count')) {
    localStorage.setItem('sm_sales_count', "0");
}

// Funciones de ayuda para obtener/guardar datos
const getProducts = () => JSON.parse(localStorage.getItem('sm_products'));
const saveProducts = (prods) => localStorage.setItem('sm_products', JSON.stringify(prods));
const getSalesCount = () => parseInt(localStorage.getItem('sm_sales_count'));
const updateSalesCount = (qty) => localStorage.setItem('sm_sales_count', getSalesCount() + qty);

// 2. Ejecutar lógica según la página en la que estemos
document.addEventListener('DOMContentLoaded', () => {

    // Si estamos en el Dashboard (index.html)
    if (document.getElementById('total-products')) {
        document.getElementById('total-products').innerText = getProducts().length;
        document.getElementById('total-sales').innerText = getSalesCount();
    }

    // Si estamos en Inventario (inventory.html)
    if (document.getElementById('inventoryBody')) {
        renderInventory();
    }

    // Si estamos en Registro (register.html)
    if (document.getElementById('productForm')) {
        document.getElementById('productForm').addEventListener('submit', (e) => {
            e.preventDefault();
            let products = getProducts();
            const newProduct = {
                id: Date.now(), // ID único basado en tiempo
                name: document.getElementById('prodName').value,
                category: document.getElementById('prodCategory').value,
                price: parseFloat(document.getElementById('prodPrice').value),
                stock: parseInt(document.getElementById('prodStock').value)
            };
            products.push(newProduct);
            saveProducts(products);
            alert("Producto guardado correctamente");
            e.target.reset();
        });
    }

    // Si estamos en Ventas (sales.html)
    if (document.getElementById('saleProductSelect')) {
        const select = document.getElementById('saleProductSelect');
        const products = getProducts();

        products.forEach(p => {
            select.innerHTML += `<option value="${p.id}">${p.name} (Stock: ${p.stock})</option>`;
        });

        document.getElementById('btnSale').addEventListener('click', () => {
            const id = parseInt(select.value);
            const qty = parseInt(document.getElementById('saleQuantity').value);
            let allProducts = getProducts();

            const productIndex = allProducts.findIndex(p => p.id === id);

            if (productIndex !== -1 && allProducts[productIndex].stock >= qty) {
                allProducts[productIndex].stock -= qty;
                saveProducts(allProducts);
                updateSalesCount(qty);
                alert(`Venta registrada exitosamente!`);
                location.reload(); // Recarga para actualizar el dropdown
            } else {
                alert("Verifica que seleccionaste un producto y que haya stock suficiente.");
            }
        });
    }
});

// Función de búsqueda para inventory.html
function searchProduct() {
    const filter = document.getElementById('searchBar').value.toLowerCase();
    const rows = document.querySelectorAll('#inventoryTable tbody tr');

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

// Función para pintar la tabla de inventario
function renderInventory() {
    const tbody = document.getElementById('inventoryBody');
    const products = getProducts();
    tbody.innerHTML = '';

    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5">No hay productos en el inventario.</td></tr>';
        return;
    }

    products.forEach(p => {
        tbody.innerHTML += `
            <tr>
                <td>${p.id}</td>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td>$${p.price.toFixed(2)}</td>
                <td>${p.stock}</td>
            </tr>
        `;
    });
}